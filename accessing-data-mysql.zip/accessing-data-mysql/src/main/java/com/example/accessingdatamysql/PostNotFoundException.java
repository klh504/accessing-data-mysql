package com.example.accessingdatamysql;

class PostNotFoundException extends RuntimeException {

    PostNotFoundException(Integer id) {
        super("Could not find post " + id);
    }
}
